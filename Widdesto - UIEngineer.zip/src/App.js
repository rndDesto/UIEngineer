import React, { Component } from 'react';
import './assets/css/style.css';
import images from './assets/img/image.jpg';
import images2 from './assets/img/image2.jpg';
import images3 from './assets/img/image3.jpg';
import cart from './assets/img/cart.svg';
import check from './assets/img/check.svg';
import quicklook from './assets/img/quicklook.svg';
import CardComponent from './Component/CardComponent';
import DetailComponent from './Component/DetailComponent';

class App extends Component {
  state={
    tabSpek : {
      konten: true,
      addClass: 'active'
    },
    tabFitur : {
      konten: false,
      addClass: ''
    },
    detailProduct : false,
    produk:
      {
        nama_produk:'Bose Soundlink',
        harga:'$ 199',
        teaser_produk:'Little speaker. Big goosebumps',
        decs_produk:'Wireless earphones for music lovers who live to move',
        spek_produk:['Up to 8 hours playtime', 'Powerful sound', 'Wireless earphone'],
        fitur_produk:['Bumper for bumping','All sound no seam', 'Grab and go'],
        ket_produk:'Free shipping & returns + 2 year warranty'
      }
  }

  onTabSpek = () => {
    this.setState({
      tabSpek : {
        konten: true,
        addClass: 'active'
      },
      tabFitur : {
        konten: false,
        addClass: ''
      }
    });
  }

  onTabFitur = () => {
    this.setState({
      tabSpek : {
        konten: false,
        addClass: ''
      },
      tabFitur : {
        konten: true,
        addClass: 'active'
      }
    });
  }

  onShowModal = () => {
    this.setState({
      detailProduct : true,
    });
  }

  onCloseModal = () => {
    this.setState({
      detailProduct : false,
    });
  }


  render() {
    let detailProduct = null;
    if ( this.state.detailProduct ) {
      detailProduct = (
        <DetailComponent
          produk={this.state.produk}
          tabSpek = {this.state.tabSpek}
          tabFitur = {this.state.tabFitur}
          onTabSpek={this.onTabSpek}
          onTabFitur={this.onTabFitur}
          onCloseModal={this.onCloseModal} 
          images={images}
          images2={images2}
          images3={images3}
          cart={cart}
          check={check}
          quicklook={quicklook}
        />
      )
    }
    return (
      <div className="App">
        <div className="container">
          <CardComponent 
            produk={this.state.produk}
            images={images}
            quicklook={quicklook}
            onShowModal={this.onShowModal}
          />
        </div>
        {detailProduct}
        
      </div>
    );
  }
}

export default App;
