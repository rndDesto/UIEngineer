import React from 'react'

const ProdukSliderComponent = (props) => {
  return (
    <div className="detail-slider">
        <div className="best-seller gotham-medium">BestSeller</div>
        <input type="radio" name="images" className="slider-panel" id="slide-1" defaultChecked />
        <input type="radio" name="images" className="slider-panel" id="slide-2" />
        <input type="radio" name="images" className="slider-panel" id="slide-3" />
        <div className="slider-img" id="imgslide-1">
            <img className="img-cover" src={props.images} alt="imgsatu" />
        </div>
        <div className="slider-img" id="imgslide-2">
            <img className="img-cover" src={props.images2} alt="imgdua" />
        </div>
        <div className="slider-img" id="imgslide-3">
            <img className="img-cover" src={props.images3} alt="imgtiga" />
        </div>
        <div className="slider-nav">
            <label className="dots" id="nav-1" htmlFor="slide-1" />
            <label className="dots" id="nav-2" htmlFor="slide-2" />
            <label className="dots" id="nav-3" htmlFor="slide-3" />
        </div>
	</div>
  )
}

export default ProdukSliderComponent
