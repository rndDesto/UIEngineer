import React from 'react'

const ProdukDescComponent = (props) => {
	let spek = null;
	let fitur = null;
	if ( props.tabSpek.konten ) {
		spek = (
			<div className="deskripsi-tabbing">
				<ul>
				{
					props.produk.spek_produk.map((desc, index) => {
					return (
						<li key={index}><span><img src={props.check} alt="check"/></span>{desc}</li>
						)
					})
				}
				</ul>
				<div className="deskripsi-color">
					<h3 className="gotham-medium font-black">Choose your colors</h3>
					<div>
						<div className="choose-color choose-grey selected"></div>
						<div className="choose-color choose-black"></div>
						<div className="choose-color choose-gold"></div>
					</div>
				</div>
			</div>
		);
	}

	if (props.tabFitur.konten) {
		fitur = (
			<div className="deskripsi-tabbing">
			<ul className="with-check">
				{
					props.produk.fitur_produk.map((fitur, index) => {
					return (
						<li key={index}><span><img src={props.check} alt="check"/></span>{fitur}</li>
						)
					})
				}
				</ul>
			</div>
		);
	}

  return (
    <div className="detail-deskripsi">
			<div className="deskripsi-kontent">
				<h2 className="font-black gotham-medium">{props.produk.nama_produk}</h2>
				<h3 className="font-black gotham-light pt-10 pb-10">{props.produk.harga}</h3>
				<div className="deskripsi-produk gotham-light">
					<p>{props.produk.decs_produk}</p>
				</div>
				<div className={`heading-tab ${props.tabSpek.addClass}`} onClick={props.onTabSpek}>Spesification</div>
				<div className={`heading-tab ${props.tabFitur.addClass}`} onClick={props.onTabFitur}>Features</div>
				{spek}
				{fitur}
				<div className="keterangan-produk">
					<ul className="with-check">
					<li><span><img src={props.check} alt="check"/></span>{props.produk.ket_produk}</li>
					</ul>
				</div>

				<div className="btn-property btn-property-black">
					<div className="btn-view" onClick={props.onShowModal}>
						<img className="img-responsive icon-cart" width="22" src={props.cart} alt="imgsatu" />
					</div>
					<div className="btn-price">
						<a className="font-white fs-14" href="">BUY NOW</a>
					</div>
				</div>
			</div>
    </div>
  )
}

export default ProdukDescComponent
