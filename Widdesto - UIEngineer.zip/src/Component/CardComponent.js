import React from 'react'

const CardComponent = (props) => {
  return (
    <div className="card">
      <div className="card-thumb">
        <div className="pos-rel">
          <img className="img-responsive img-cover-2" src={props.images} alt="imgsatu" />
        </div>
      </div>
      <div className="card-body">
        <h3 className="gotham-medium card-heading">{props.produk.nama_produk}</h3>
        <div className="best-seller gotham-medium">BestSeller</div>
        <div className="card-content">
          <p>{props.produk.teaser_produk}</p>
        </div>
        <div className="btn-property">
          <div className="btn-view" onClick={props.onShowModal}>
            <img className="img-responsive icon-view" src={props.quicklook} alt="imgsatu" />
          </div>
          <div className="btn-price">
            <span>{props.produk.harga}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CardComponent
