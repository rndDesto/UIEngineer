import React from 'react'
import ProdukSliderComponent from './ProdukSliderComponent';
import ProdukDescComponent from './ProdukDescComponent';

const DetailComponent = (props) => {
	return (
		<div>
			<div className="overlay"></div>
			<div className="modal">
				<div className="modal-dialog">
					<div className="modal-content detail-produk container">
						<div className="modal-close" onClick={props.onCloseModal}>X</div>
							<div className="ovh">
								<ProdukSliderComponent 
									images={props.images}
									images2={props.images2}
									images3={props.images3}
								/>
								<ProdukDescComponent
									produk={props.produk}
									tabSpek={props.tabSpek}
									tabFitur={props.tabFitur}
									check={props.check}
									cart={props.cart}
									onTabSpek={props.onTabSpek}
									onTabFitur={props.onTabFitur}
								/>
							</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default DetailComponent
