$(document).ready(function() {
	headline_banner();
	body_scroll();
	welcome_type();
	menu_mobile();
	form_validation();
	skill_circ();
	
});

const headline_banner = () => {
	let bg_head = $(".headline-banner");
	let bg_banner = $(".bg-banner");
	let movementStrength = 15;
	let height = movementStrength / $(window).height();
	let width = movementStrength / $(window).width();
	bg_head.mousemove(function(e){
		let pageX = e.pageX - ($(window).width() / 5);
		let pageY = e.pageY - ($(window).height() / 5);
		let newvalueX = width * pageX * -1 - 25;
		let newvalueY = height * pageY * -1 - 50;
		bg_banner.css("background-position", newvalueX+"px     "+newvalueY+"px");
	});
}

const body_scroll = () => {
	let nav = $(".headline-nav");
	let bannerHeight = $(".headline-banner").outerHeight();
	// console.log(bannerHeight);
	$('body').scrollspy({
		target: "#prime-nav",
		offset: 120
	});


	$("#prime-nav a, .mouse-icon").on('click', function(e) {
		if (this.hash !== "") {
			e.preventDefault();
			let hash = this.hash;
			$('html, body').animate({
				scrollTop: $(hash).offset().top
			}, 200);
		}
	});

	const scr_menu = () => {
		let sctop = $(window).scrollTop();
		if(sctop > bannerHeight){
			nav.addClass("headline-nav-fixed").removeClass("headline-nav-absolute");
		}
		else if(sctop == 0){
			nav.removeClass("headline-nav-absolute headline-nav-fixed");
		}
		else{
			nav.addClass("headline-nav-absolute").removeClass("headline-nav-fixed");
		}
	}
	$(window).on('scroll',scr_menu);
}

const welcome_type = () => {
	var TxtType = function (el, toRotate, period) {
		this.toRotate = toRotate;
		this.el = el;
		this.loopNum = 0;
		this.period = parseInt(period, 10) || 1000;
		this.txt = '';
		this.tick();
		this.isDeleting = false;
	};

	TxtType.prototype.tick = function () {
		var i = this.loopNum % this.toRotate.length;
		var fullTxt = this.toRotate[i];

		if (this.isDeleting) {
			this.txt = fullTxt.substring(0, this.txt.length - 1);
		} else {
			this.txt = fullTxt.substring(0, this.txt.length + 1);
		}

		this.el.innerHTML = '<span class="wrap">' + this.txt + '</span>';

		var that = this;
		var delta = 100 - Math.random() * 100;

		if (this.isDeleting) {
			delta /= 2;
		}

		if (!this.isDeleting && this.txt === fullTxt) {
			delta = this.period;
			this.isDeleting = true;
		} else if (this.isDeleting && this.txt === '') {
			this.isDeleting = false;
			this.loopNum++;
			delta = 500;
		}

		setTimeout(function () {
			that.tick();
		}, delta);
	};



	let elements = $('.typewrite');
	for (let i = 0; i < elements.length; i++) {
		let toRotate = elements[i].getAttribute('data-type');
		let period = elements[i].getAttribute('data-period');
		if (toRotate) {
			new TxtType(elements[i], JSON.parse(toRotate), period);
		}
	}
}

const section_scroll = () => {
	//init ScrollMagic
	let controller = new ScrollMagic.Controller();
	let scroll_selector = $(".scroll-animation");
	

	//Build  Scene
	scroll_selector.each(function(){
		let section = new ScrollMagic.Scene({
			triggerElement: this,//selector to start
			duration: "100%", // how long scroll triggered
			triggerHook: "0.5" // start point to run trigger
			// reverse: false // animation oly run once after scroll triggered
		})
		.setClassToggle( this,"fade-in")
		.addIndicators({
			name: "section",
			colorTrigger:"black",
			colorStart:"black",
			colorEnd:"blue"
		})
		.addTo(controller);
	});

	let nav = new ScrollMagic.Scene({
		triggerElement: "#scroll-id-0",
		triggerHook: "0.1"
	})
	.setClassToggle( ".headline-nav","position-fixed")
	.addIndicators({
		name: "navigation",
		colorTrigger:"black",
		colorStart:"black",
		colorEnd:"blue",
		indent: 200
	})
	.addTo(controller);
}

const menu_mobile = () =>{
	let menu = $(".navbar-menu-mobile");
	let menu_parent = $(".headline-nav"); 

	menu.on('click', function(){
		menu_parent.toggleClass("headline-nav-mobile");
	});
}


// function initMap() {
// 	let my_loc = {
// 		lat: -6.418177,
// 		lng: 106.860649
// 	};

// 	let map = new google.maps.Map(
// 			document.getElementById('map'), {
// 				zoom: 16,
// 	  center: my_loc,
// 			});

// 	let marker = new google.maps.Marker({
// 		position: my_loc,
// 		map: map
// 	});
// }



const form_validation =() =>{
	let form = $("#form-user");
	form.submit(function(e) {
		e.preventDefault();
		let me = $(this);
		let btn_send = form.find("#send-me");
		
		btn_send.addClass("disabled").text("Sending...");
		$.ajax({
			url: me.attr("action"),
			type: 'POST',
			dataType: 'JSON',
			data: me.serialize(),
			success: function(response){
				if (response.success == true) {
					me[0].reset();
					me.closest(".form-group").find(".text-danger").remove();
					setTimeout(function(){
						console.log("satu");
					},1000);
					btn_send.removeClass("disabled").text("Send Me");
				}
				else {
					$.each(response.messages, function(key, val) {
						let element = $("#form-" + key);
						element.closest(".form-group").find(".text-danger").remove();
						$(val).appendTo(element);
					});
					btn_send.removeClass("disabled").text("Send Again");

					setTimeout(function(){
						console.log("gagal");
					},1000);
				}
			}
		})
		.done(function() {
			setTimeout(function(){
				console.log("dua");
			},1000);
		})
		.always(function() {
			setTimeout(function(){
				console.log("tiga");
			},1000);
		});
		
	});
}


const skill_circ = () => {
	$(".skill-circ").each(function() {
		$(this).circleChart({
			size: 160,
			color: '#f57676',
			backgroundColor: '#ebebeb',
			animate: true,
			startAngle: 75,
			text: 0 + '%',
			redraw: true,
			onDraw: function(el, circle){
				$(".circleChart_text", el).html(Math.round(circle.value) + '%');
			}
		});
	});
}




function mouse_enters(e){
	/** the width and height of the current div **/
	var w = $(this).width();
	var h = $(this).height();
	var speed = 100;
	
	/** calculate the x and y to get an angle to the center of the div from that x and y. **/
	/** gets the x value relative to the center of the DIV and "normalize" it **/
	var x = (e.pageX - this.offsetLeft - (w/2)) * ( w > h ? (h/w) : 1 );
	var y = (e.pageY - this.offsetTop  - (h/2)) * ( h > w ? (w/h) : 1 );
	
	/** the angle and the direction from where the mouse came in/went out clockwise (TRBL=0123);**/
	/** first calculate the angle of the point, 
   add 180 deg to get rid of the negative values
   divide by 90 to get the quadrant
   add 3 and do a modulo by 4  to shift the quadrants to a proper clockwise TRBL (top/right/bottom/left) **/
	var direction = Math.round((((Math.atan2(y, x) * (180 / Math.PI)) + 180 ) / 90 ) + 3 )  % 4;
	var el_height = $(this).height();
	var el_width = $(this).width();
	
	/** do your animations here **/ 
	switch(direction) {
	  case 0:
		/** animations from the TOP **/
		$(this).find('.porto-hover')
		.show()
		.css({'top': '-'+el_height+'px', 'left': '0px'})
		.animate({ top: 0 }, speed);
		break;
	  case 1:
		/** animations from the RIGHT **/
		$(this).find('.porto-hover')
		.show()
		.css({'left': el_width+'px', 'top': '0px'})
		.animate({ left: 0 }, speed);
		break;
	  case 2:
		/** animations from the BOTTOM **/
		$(this).find('.porto-hover')
		.show()
		.css({'top': el_height+'px', 'left': '0px'})
		.animate({ top: 0 }, speed);
		break;
	  case 3:
		/** animations from the LEFT **/
		$(this).find('.porto-hover')
		.show()
		.css({'left': '-'+el_width+'px', 'top': '0px'})
		.animate({ left: 0 }, speed);
		break;
	}
  }
  
  function mouse_leaves(e){
	/** the width and height of the current div **/
	var w = $(this).width();
	var h = $(this).height();
	var speed = 100;
	
	/** calculate the x and y to get an angle to the center of the div from that x and y. **/
	/** gets the x value relative to the center of the DIV and "normalize" it **/
	var x = (e.pageX - this.offsetLeft - (w/2)) * ( w > h ? (h/w) : 1 );
	var y = (e.pageY - this.offsetTop  - (h/2)) * ( h > w ? (w/h) : 1 );
	
	/** the angle and the direction from where the mouse came in/went out clockwise (TRBL=0123);**/
	/** first calculate the angle of the point, 
   add 180 deg to get rid of the negative values
   divide by 90 to get the quadrant
   add 3 and do a modulo by 4  to shift the quadrants to a proper clockwise TRBL (top/right/bottom/left) **/
	var direction = Math.round((((Math.atan2(y, x) * (180 / Math.PI)) + 180 ) / 90 ) + 3 )  % 4;
	var el_height = $(this).height();
	var el_width = $(this).width();
	
	/** do your animations here **/ 
	switch(direction) {
	  case 0:
		/** animations from the TOP **/
		$(this).find('.porto-hover')
		.animate({ top: '-'+el_height+'px' }, speed);
		break;
	  case 1:
		/** animations from the RIGHT **/
		$(this).find('.porto-hover')
		.animate({ left: el_width+'px' }, speed);
		break;
	  case 2:
		/** animations from the BOTTOM **/
		$(this).find('.porto-hover')
		.animate({ top: el_height+'px' }, speed);
		break;
	  case 3:
		/** animations from the LEFT **/
		$(this).find('.porto-hover')
		.animate({ left: '-'+el_width+'px' }, speed);
		break;
	}
  }
  


